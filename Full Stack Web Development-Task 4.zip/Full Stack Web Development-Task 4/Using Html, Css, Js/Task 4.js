const inputBox = document.getElementById("input-box");
const listContainer = document.getElementById("list-container");
const clearAllBtn = document.getElementById("clear-all-btn");

function addTask() {
    if (inputBox.value === '') {
        alert("You must fill the field!");
    } else {
        let li = document.createElement("li");
        li.innerHTML = inputBox.value;
        listContainer.appendChild(li);
        let span = document.createElement("span");
        span.innerHTML = "\u00D7"; // ////////////////////// "x" symbol
        li.appendChild(span);
        inputBox.value = "";
        updateClearAllButton();
        saveData();
    }
}

function clearAll() {
    listContainer.innerHTML = "";
    clearAllBtn.style.display = "none";
    localStorage.removeItem("data");
}

function updateClearAllButton() {
    if (listContainer.children.length > 1) {
        clearAllBtn.style.display = "block";
    } else {
        clearAllBtn.style.display = "none";
    }
}

inputBox.addEventListener("keypress", function (event) {
    if (event.key === "Enter") {
        addTask();
    }
});

listContainer.addEventListener("click", function (e) {
    if (e.target.tagName === "LI") {
        e.target.classList.toggle("checked");
        saveData();
    } else if (e.target.tagName === "SPAN") {
        e.target.parentElement.remove();
        updateClearAllButton();
        saveData();
    }
}, false);

function saveData() {
    localStorage.setItem("data", listContainer.innerHTML);
}

function showTask() {
    listContainer.innerHTML = localStorage.getItem('data');
    updateClearAllButton();
}

showTask();