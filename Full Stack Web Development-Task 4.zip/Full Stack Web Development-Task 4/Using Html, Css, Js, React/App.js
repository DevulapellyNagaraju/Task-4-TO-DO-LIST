const { useState, useEffect } = React;

function App() {
  const [tasks, setTasks] = useState(() => {
    // Load tasks from localStorage when the component mounts
    const savedTasks = localStorage.getItem('tasks');
    return savedTasks ? JSON.parse(savedTasks) : [];
  });
  const [taskInput, setTaskInput] = useState('');

  useEffect(() => {
    // Save tasks to localStorage whenever the tasks state changes
    localStorage.setItem('tasks', JSON.stringify(tasks));
  }, [tasks]);

  const addTask = () => {
    if (!taskInput.trim()) {
      alert('Please enter a task!');
      return;
    }
    setTasks([...tasks, { text: taskInput, completed: false }]);
    setTaskInput('');
  };

  const toggleTaskCompletion = (index) => {
    const newTasks = tasks.map((task, i) => (
      i === index ? { ...task, completed: !task.completed } : task
    ));
    setTasks(newTasks);
  };

  const deleteTask = (index) => {
    const newTasks = tasks.filter((_, i) => i !== index);
    setTasks(newTasks);
  };

  const removeAllTasks = () => {
    setTasks([]);
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter') {
      addTask();
    }
  };

  return (
    <div className="todo-container">
      <h1>
        <i className="fas fa-tasks"></i> To-Do List
      </h1>
      <div className="input-container">
        <input
          type="text"
          value={taskInput}
          onChange={(e) => setTaskInput(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Enter a new task"
        />
        <button id="taskbtn" onClick={addTask}>Add</button>
      </div>
      <ul className="task-list">
        {tasks.map((task, index) => (
          <li key={index} className={`task-item ${task.completed ? 'completed' : ''}`}>
            <span id="spandoubt1" onClick={() => toggleTaskCompletion(index)}>
              {task.text}
            </span>
            <button className="delete-btn" onClick={() => deleteTask(index)}>×</button>
          </li>
        ))}
      </ul>
      {tasks.length > 1 && (
        <div className="remove-all-container">
          <button onClick={removeAllTasks}>Clear All</button>
        </div>
      )}
    </div>
  );
}

ReactDOM.render(<App />, document.getElementById('root'));
